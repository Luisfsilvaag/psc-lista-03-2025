using System;
class HelloWorld {
  static void Main() {
      
      Console.WriteLine("Digite o primeiro número inteiro: ");
        int num1 = int.Parse(Console.ReadLine());
        
        Console.WriteLine("Digite o segundo número inteiro: ");
        int num2 = int.Parse(Console.ReadLine());
        
        int menor, maior;
        if (num1 < num2)
        {
            menor = num1;
            maior = num2;
        }
        else
        {
            menor = num2;
            maior = num1;
        }

        Random random = new Random();
        int numeroSorteado = random.Next(menor, maior + 1);

        if (numeroSorteado % 2 == 0)
        {
            Console.WriteLine("O número sorteado foi " + numeroSorteado + " e ele é PAR.");
        }
        else
        {
            Console.WriteLine("O número sorteado foi " + numeroSorteado + " e ele é ÍMPAR.");
        }
    
  }
}