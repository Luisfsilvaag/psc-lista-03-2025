using System;
class HelloWorld {
  static void Main() {
      
    Console.WriteLine("Digite o valor da compra: ");
    int preco = int.Parse(Console.ReadLine());
    
    Console.WriteLine("Digite o valor pago: ");
    int pagamento = int.Parse(Console.ReadLine());
    
    if (pagamento < preco)
    {
        Console.WriteLine("O valor pago é insuficiente para finalizar a compra");
    }
    
    else
    {
        
        int troco = pagamento - preco;
        Console.WriteLine("Troco: " + troco);
        
        int notas;
        
        notas = troco / 50;
        if (notas > 0)
        {
            Console.WriteLine(notas + " notas de R$50");
            troco -=  notas * 50;
        }
        
        notas = troco / 20;
        if (notas > 0)
        {
            Console.WriteLine(notas + " notas de R$20");
            troco -=  notas * 20;
        }
        
        notas = troco / 10;
        if (notas > 0)
        {
            Console.WriteLine(notas + " notas de R$10");
            troco -=  notas * 10;
        }
        
        notas = troco / 5;
        if (notas > 0)
        {
            Console.WriteLine(notas + " notas de R$5");
            troco -=  notas * 5;
        }
        
        notas = troco / 2;
        if (notas > 0)
        {
            Console.WriteLine(notas + " notas de R$2");
            troco -=  notas * 2;
        }
        
        notas = troco / 1;
        if (notas > 0)
        {
            Console.WriteLine(notas + " notas de R$1");
            troco -=  notas * 1;
        }
        
    }
  }
}