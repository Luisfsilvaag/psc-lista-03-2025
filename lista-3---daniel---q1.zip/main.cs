using System;
class main {
  static void Main() {
    
    Console.WriteLine("Digite o primeiro número");
    int num1 = int.Parse(Console.ReadLine());
    
    Console.WriteLine("Digite o segundo número");
    int num2 = int.Parse(Console.ReadLine());
    
    Console.WriteLine("Digite o terceiro número");
    int num3 = int.Parse(Console.ReadLine());
    
    if (num1 > num2 && num1 > num3)
    {
        Console.WriteLine("O numero maior é " + num1);
    }
    
    else if (num2 > num3 && num2 > num1)
    {
        Console.WriteLine("O numero maior é " + num2);
    }
    
    else if (num3 > num1 && num3 > num2)
    {
        Console.WriteLine("O maior numero é: " + num3);
    }
    
    float media = ((num1 + num2 + num3) / 3);
    
    Console.WriteLine("A média entre os números é: " + media);
    
    
  }
}