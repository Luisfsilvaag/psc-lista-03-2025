using System;
class HelloWorld {
  static void Main() {
      
    Console.WriteLine(@"Qual medida deseja calcular?
    1 - Perimetro
    2 - Area
    3 - Volume");
    
    int operacao = int.Parse(Console.ReadLine());
    
    Console.WriteLine("Informe o raio da esfera/círculo");
    
    float r = float.Parse(Console.ReadLine());
    
    if (operacao != 1 && operacao != 2 && operacao != 3 )
    {
        Console.WriteLine("Código da operação inválido.");
    }
    
        else
        {
            double pi = 3.141592;
            
            if(operacao == 1)
            {
                double perimetro = (2 * pi * r);
                
                Console.WriteLine("O perimetro é: " + perimetro);
            }
            
            if(operacao == 2)
            {
                double area = (pi * (r * r));
                
                Console.WriteLine("A área do círculo é: " + area);
            }
            
            if(operacao == 3)
            {
                double volume = (4.0 / 3.0 * pi * (r * r * r));
                
                Console.WriteLine("O volume da esfera é: " + volume);
            }
        }
  }
}