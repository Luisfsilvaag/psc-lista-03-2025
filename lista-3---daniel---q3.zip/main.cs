// delta = b2 – 4ac

using System;
class HelloWorld {
  static void Main() {
      
    Console.WriteLine("Digite o valor do coeficiente A: ");
    float a = float.Parse(Console.ReadLine());
    
    Console.WriteLine("Digite o valor do coeficiente B: ");
    float b = float.Parse(Console.ReadLine());
    
    Console.WriteLine("Digite o valor do coeficiente C: ");
    float c = float.Parse(Console.ReadLine());
    
    double delta = (b*b) - (4*a*c);
    
    if (a == 0 && b == 0 && c != 0)
    {
        Console.WriteLine("Coeficientes informados incorretamente");
    }
    
    else
    {
        if (a == 0 && b != 0)
        {
            float raiz1grau = (-c / b);
            Console.WriteLine("Essa é uma equação de primeiro grau, de raiz: " + raiz1grau);
        }
        
        if(delta < 0)
        {
            Console.WriteLine("Esta equação não possui raizes reais");
        }
        
        if(delta == 0)
        {
            double raiz1 = (-b + Math.Sqrt(delta)) / (2 * a);
            double raiz2 = (-b - Math.Sqrt(delta)) / (2 * a);
            
            Console.WriteLine("Essa equacao possui duas raizes reais iguais, sendo: " + raiz1 + " e " + raiz2);
        }
        
        if(delta > 0)
        {
            double raiz1 = (-b + Math.Sqrt(delta)) / (2 * a);
            double raiz2 = (-b - Math.Sqrt(delta)) / (2 * a);
            
            Console.WriteLine("Essa equacao possui duas raizes reais diferentes, sendo: " + raiz1 + " e " + raiz2);
        }
    }
  }
}