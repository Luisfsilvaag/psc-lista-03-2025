using System;
class HelloWorld {
  static void Main() {
      
    Console.WriteLine("Digite o primeiro algarismo");
    float dig1 = float.Parse(Console.ReadLine());
    
    Console.WriteLine("Digite o segundo algarismo");
    float dig2 = float.Parse(Console.ReadLine());
      
    Console.WriteLine(@"Qual operação deseja realizar?
    1 - Adição
    2 - Subtração
    3 - Multiplicação
    4 - Divisão");
    
    int operacao = int.Parse(Console.ReadLine());
    
    if (operacao != 1 && operacao != 2 && operacao != 3 && operacao != 4 && operacao != 5)
    {
        Console.WriteLine("Código da operação inválido.");
    }
    
    else
    {
        if(operacao == 1)
        {
            float total = dig1 + dig2;
            Console.WriteLine("O total é: " + total);
        }
        
        if(operacao == 2)
        {
            float resto = dig1 - dig2;
            Console.WriteLine("O resto é: " + resto);
        }
        
        if(operacao == 3)
        {
            float produto = dig1 * dig2;
            Console.WriteLine("O produto é: " + produto);
        }
        
        if(operacao == 4)
        {
            float quociente = dig1 / dig2;
            Console.WriteLine("O quociente é: " + quociente);
        }
        
    }
    
  }
}